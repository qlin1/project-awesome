$(".dropdown-button").dropdown();
$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15 // Creates a dropdown of 15 years to control year
  });
$(document).ready(function() {
$('select').material_select();
});
$(document).ready(function(){
      $('.parallax').parallax();
    });